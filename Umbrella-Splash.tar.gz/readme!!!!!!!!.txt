 How to manually install splash screens

  1  Extract the archive

  2  Go to ~/.local/share/plasma/look-and-feel/

  3  If the look-and-feel folder isn't there just create it

  4  Paste the extracted content in step 1 inside

  5  Now just open the kde settings GUI & change the splash screen
